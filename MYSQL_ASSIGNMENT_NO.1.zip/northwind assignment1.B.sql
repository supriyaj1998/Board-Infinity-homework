-- Q.1 B. Northwind Database Exercises :-

use northwind;

select * from products;

-- 1. Write a query to get Product name and quantity/unit
      select ProductName, QuantityPerUnit from products;

-- 2. Write a query to get current Product list (Product ID and name)
      select ProductID, ProductName, UnitsInStock from products;
      
-- 3. Write a query to get discontinued Product list (Product ID and name)
	  select ProductID, ProductName, Discontinued from products;
      
-- 4. Write a query to get most expense and least expensive Product list (name and unit price)
      select ProductName, UnitPrice from products order by UnitPrice desc;
      
-- 5. Write a query to get Product list (id, name, unit price) where current products cost less than $20
      select ProductID, ProductName, UnitPrice from products where((UnitPrice) < 20) order by UnitPrice desc;
      
-- 6. Write a query to get Product list (id, name, unit price) where products cost between $15 and $25      
      select ProductID, ProductName, UnitPrice from products where UnitPrice between 15 and 25;

-- 7. Write a query to get Product list (name, unit price) of above average price
      select distinct ProductName, UnitPrice from products where UnitPrice > (select avg(UnitPrice) from products) order by UnitPrice; 

-- 8. Write a query to get Product list (name, unit price) of ten most expensive products
      select distinct ProductName, UnitPrice from products as A where 10>=(select count(distinct UnitPrice)from products as B where B.UnitPrice>= A.UnitPrice) order by UnitPrice desc;

-- 9. Write a query to count current and discontinued products
select count(UnitsInStock),count(Discontinued) from products;

-- 10. Write a query to get Product list (name, units on order , units in stock) of stock is less than the quantity on order
select ProductName, UnitsOnOrder, UnitsInStock from products where ((UnitsInStock) < (UnitsOnOrder));