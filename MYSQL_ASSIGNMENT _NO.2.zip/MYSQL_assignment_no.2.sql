/*
Task 1: Understanding the data :
A. Describe the data in hand in your own words. (Word Limit is 500)
	1. cust_dimen: Details of all the customers
		
        Customer_Name (TEXT): Name of the customer
        Province (TEXT): Province of the customer
        Region (TEXT): Region of the customer
        Customer_Segment (TEXT): Segment of the customer
        Cust_id (TEXT): Unique Customer ID
	
    2. market_fact: Details of every order item sold
		
        Ord_id (TEXT): Order ID
        Prod_id (TEXT): Prod ID
        Ship_id (TEXT): Shipment ID
        Cust_id (TEXT): Customer ID
        Sales (DOUBLE): Sales from the Item sold
        Discount (DOUBLE): Discount on the Item sold
        Order_Quantity (INT): Order Quantity of the Item sold
        Profit (DECIMAL): Profit from the Item sold
        Shipping_Cost (DOUBLE): Shipping Cost of the Item sold
        Product_Base_Margin (DOUBLE): Product Base Margin on the Item sold
        
    3. orders_dimen: Details of every order placed
		
        Order_ID (INT): Order ID
        Order_Date (TEXT): Order Date
        Order_Priority (TEXT): Priority of the Order
        Ord_id (TEXT): Unique Order ID
	
    4. prod_dimen: Details of product category and sub category
		
        Product_Category (TEXT): Product Category
        Product_Sub_Category (TEXT): Product Sub Category
        Prod_id (TEXT): Unique Product ID
	
    5. shipping_dimen: Details of shipping of orders
		
        Order_ID (INT): Order ID
        Ship_Mode (TEXT): Shipping Mode
        Ship_Date (TEXT): Shipping Date
        Ship_id (TEXT): Unique Shipment ID
        
B. Identify and list the Primary Keys and Foreign Keys for given dataset:
(Hint: If a table don’t have Primary Key or Foreign Key, then specifically mention it in your answer.)
	1. cust_dimen
		Primary Key: Cust_id
        Foreign Key: NA
	
    2. market_fact
		Primary Key: NA
        Foreign Key: Ord_id, Prod_id, Ship_id, Cust_id
	
    3. orders_dimen
		Primary Key: Ord_id
        Foreign Key: NA
	
    4. prod_dimen
		Primary Key: Prod_id, Product_Sub_Category
        Foreign Key: NA
	
    5. shipping_dimen
		Primary Key: Ship_id
        Foreign Key: NA
 */
 

-- Task 2: Basic Analysis :
-- Write the SQL queries for the following:


CREATE DATABASE SUPERSTORE; -- creating Database
USE SUPERSTORE;             -- using created Database

-- Creating Tables For Database :
CREATE TABLE cust_dimen(Customer_Name char(20), Province char(50), Region char(50),Customer_Segment char(50),Cust_id varchar(20));
select * from cust_dimen;
CREATE TABLE market_fact(Ord_id varchar(30), Prod_id varchar(30), Ship_id varchar(30),Cust_id varchar(30),Sales float(20),Discount float(20),Order_Quantity int, Profit decimal(30),Shipping_Cost varchar(20),Product_Base_Margin float(20));
select * from market_fact;
select * from orders_dimen;
select * from prod_dimen;
select * from shipping_dimen;

-- 1. Write a query to display the Customer_Name and Customer Segment using alias name “Customer Name", "Customer Segment" from table Cust_dimen.
 select	Customer_Name "Customer Name",Customer_Segment"Customer Segment" from cust_dimen;
 
-- 2. Write a query to find all the details of the customer from the table cust_dimen order by desc.
 select * from cust_dimen order by customer_name;
 
-- 3. Write a query to get the Order ID, Order date from table orders_dimen where ‘Order Priority’ is high.
 select Order_ID,Order_Date from orders_dimen where Order_Priority = "HIGH";
 
-- 4. Find the total and the average sales (display total_sales and avg_sales) 
 select sum(Sales) as Total_sales, avg(Sales) as Avg_sales from market_fact;
 
-- 5. Write a query to get the maximum and minimum sales from maket_fact table. 
 select max(Sales),min(Sales) from market_fact;
 
-- 6. Display the number of customers in each region in decreasing order of no_of_customers. The result should contain columns Region, no_of_customers. 
 select count(Cust_id) as cust_no, Customer_Name, Region from cust_dimen group by Region order by count(Cust_id) desc;
 
-- 7. Find the region having maximum customers (display the region name and max(no_of_customers) 
 select max(Cust_id) as no_of_customers,Region as 'Region Name'from cust_dimen group by region order by  max(Cust_id) limit 1;
 
-- 8. Find all the customers from Atlantic region who have ever purchased ‘TABLES’ and the number of tables purchased (display the customer name, no_of_tables purchased) 
select a.Region as "Region", a.Customer_Name as "Customer Name", b.Product_Sub_Category as "Product Sub Category", sum(c.Order_Quantity) as "Orders"
from market_fact c 
                 join cust_dimen a on c.Cust_id = a.Cust_id
                 join prod_dimen b on c.Prod_id = b.Prod_id
where a.Region = "ATLANTIC" and b.Product_Sub_Category = "TABLES"
group by a.Customer_Name 
order by sum(c.Order_Quantity) desc;

-- 9. Find all the customers from Ontario province who own Small Business. (display the customer name, no of small business owners)
select Customer_Name, count(*) as "no of small business owners" , Province, Customer_Segment from cust_dimen 
where Customer_Segment = "SMALL BUSINESS" and Province = "ONTARIO"  group by Customer_Name;

-- 10. Find the number and id of products sold in decreasing order of products sold (display product id, no_of_products sold)
 select Prod_id,sum(Order_Quantity) as "no_of_products_sold" from market_fact group by Prod_id order by sum(Order_Quantity) desc;
 
-- 11. Display product Id and product sub category whose produt category belongs to Furniture and Technlogy. The result should contain columns product id, product sub category.
 select Prod_id, Product_Sub_Category  from prod_dimen  where Product_Category in("FURNITURE","TECHNOLOGY") group by Prod_id  ;
 
-- 12. Display the product categories in descending order of profits (display the product category wise profits i.e. product_category, profits)? 
 select a.Product_Category as "Product_Category", b.Profit as "Profit"
 from market_fact b
        join  Prod_dimen a on b.Prod_id = a.Prod_id
        order by Profit desc;        
 
-- 13. Display the product category, product sub-category and the profit within each subcategory in three columns. 
 select a.Product_Category, a.Product_Sub_Category, sum(b.profit) as profit
 from market_fact b
		inner join Prod_dimen a on b.Prod_id = a.Prod_id
group by a.Product_Sub_Category,a.Product_Category;

-- 14. Display the order date, order quantity and the sales for the order.
 select a.Order_Date, b.Order_Quantity, b.Sales
 from market_fact b
		join orders_dimen a on b.Ord_id = a.Ord_id
group by Sales;
 
-- 15. Display the names of the customers whose name contains the
-- i) Second letter as ‘R’
-- ii) Fourth letter as ‘D’ 
 select Cust_id,Customer_Name from cust_dimen where Customer_Name like "_r%" and Customer_Name like "___%d";
 
 /* 16. Write a SQL query to to make a list with Cust_Id, Sales, Customer Name and their region where sales are between 1000 and 5000.*/
 select a.Cust_Id, a.Customer_Name, a.Region, b.Sales  
 from market_fact b
		join cust_dimen a on b.Cust_id = a.Cust_id
 where Sales between 1000 and 5000 order by Sales;
 
 -- 17. Write a SQL query to find the 3rd highest sales.
 select Sales from market_fact order by Sales desc limit 3 ;


-- 18. Where is the least profitable product subcategory shipped the most? For the least profitable product sub-category,
-- display the region-wise no_of_shipments and the profit made in each region in decreasing order of profits (i.e. region, no_of_shipments, profit_in_each_region)

select Profit as Profit_In_Each_Region, count(Ship_id) as no_of_shipments , Product_Sub_Category, Region
from cust_dimen
			c,market_fact
			s,prod_dimen p 
where c.Cust_id = s.Cust_id and s.Prod_id = p.Prod_id group by Region order by Profit_In_Each_Region;
	

            
